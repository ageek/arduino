Uses ds3231 RTC and SPI OLED SSD1306 chip:
http://www.instructables.com/id/DS3231-OLED-clock-with-2-button-menu-setting-and-t/