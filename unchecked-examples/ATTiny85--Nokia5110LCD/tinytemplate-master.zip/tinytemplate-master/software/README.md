This directory should contain sources for any desktop or host software that is
part of the project.
