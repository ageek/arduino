This directory should contain schematics and other design files for the physical
components of the project.