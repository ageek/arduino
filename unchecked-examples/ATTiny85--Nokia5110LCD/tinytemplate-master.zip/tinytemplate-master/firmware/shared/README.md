Shared source files and hardware drivers.
