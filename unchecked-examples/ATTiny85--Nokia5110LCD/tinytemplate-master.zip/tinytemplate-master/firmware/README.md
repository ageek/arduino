This directory contains the source files for the code to be loaded on the
processor. Commonly used files (for serial communications, LCD drivers, etc)
are available in the 'shared' and 'include' directories. The file
'include/hardware.h' is used to specify pin assignments and other hardware
configuration.
