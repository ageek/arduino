This directory contains tools and utilities to transfer code to and from a
device using the 'Microboot' boot loader protocol. It also includes the
['intelhex' library](http://www.bialix.com/intelhex/) and associated tools
from that project.

The 'intelhex' project is developed by Alexander Belchenko and released under
a [BSD license](http://www.bialix.com/intelhex/LICENSE.txt).
