var annotated_dup =
[
    [ "MD_DS1307", "class_m_d___d_s1307.html", "class_m_d___d_s1307" ]
];