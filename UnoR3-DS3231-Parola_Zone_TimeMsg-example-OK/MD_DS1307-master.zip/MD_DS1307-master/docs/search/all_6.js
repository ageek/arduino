var searchData=
[
  ['now',['now',['../class_m_d___d_s1307.html#a4b1f9684f4117a62f321e44b43fcf2a0',1,'MD_DS1307']]]
];
