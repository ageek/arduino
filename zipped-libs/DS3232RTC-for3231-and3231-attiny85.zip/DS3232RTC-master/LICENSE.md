# Arduino DS3232RTC Library v1.0 #
https://github.com/JChristensen/DS3232RTC  
LICENSE file  
Jack Christensen Mar 2013  

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)
## CC BY-SA ##
"Arduino DS3232RTC Library" by Jack Christensen is licensed under [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/).