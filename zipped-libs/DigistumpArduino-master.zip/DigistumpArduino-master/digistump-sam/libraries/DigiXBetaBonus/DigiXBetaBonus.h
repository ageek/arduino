//This file allows the DigiXBetaBonus sketches to appear in the File > Examples menu and fixes the Invalid library warning in Arduino IDE 1.6.6+
